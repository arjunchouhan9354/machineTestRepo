<?=$this->include('admin/includes/header');?>
<?= $this->renderSection("body-contents")?>
<?=$this->include('admin/includes/footer');
?>