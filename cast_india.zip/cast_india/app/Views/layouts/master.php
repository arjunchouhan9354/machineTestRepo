<?=$this->include('includes/header');
?>
<?= $this->renderSection("body-contents")?>
<?=$this->include('includes/footer');
?>